export default {
	"pages": {
		"root": {
			"id": "root",
			"pageUrl": "root",
			"name": "root",
			"children": [
				"67113ea841a0cf0024a4d2f8",
				"67113ea841a0cf0024a4d2fc",
				"672e7a7428b5e30023adedac",
				"672e7a789e74900024fe544e"
			]
		},
		"67113ea841a0cf0024a4d2f8": {
			"id": "67113ea841a0cf0024a4d2f8",
			"name": "404",
			"pageUrl": "404"
		},
		"67113ea841a0cf0024a4d2fc": {
			"id": "67113ea841a0cf0024a4d2fc",
			"name": "home",
			"pageUrl": "index"
		},
		"672e7a7428b5e30023adedac": {
			"id": "672e7a7428b5e30023adedac",
			"pageUrl": "recommendations",
			"name": "recommendations"
		},
		"672e7a789e74900024fe544e": {
			"id": "672e7a789e74900024fe544e",
			"pageUrl": "filters",
			"name": "filters"
		}
	},
	"mode": "production",
	"projectType": "create-react-app",
	"site": {
		"styles": {},
		"seo": {
			"favicon_apple_152px": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z",
			"favicon_32px": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z",
			"favicon_win10_270px": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z",
			"background_win10": "#eff0a7",
			"og:title": "Help for you — Healthcare without the system",
			"og:description": "Chat with a doctor right from your phone, all day and night. No waiting room or appointment needed.",
			"og:image": "https://uploads.quarkly.io/6123949e957019001e284458/images/OGimage.png?v=2021-09-21T16:25:40.647Z",
			"title": "Help for you — Healthcare without the system",
			"description": "Chat with a doctor right from your phone, all day and night. No waiting room or appointment needed."
		}
	}
}