import React from "react";
import theme from "theme";
import { Theme, Link, Image, Box, Em, Strong, Section, Text } from "@quarkly/widgets";
import { Helmet } from "react-helmet";
import { GlobalQuarklyPageStyles } from "global-page-styles";
import { RawHtml, Override } from "@quarkly/components";
import * as Components from "components";
export default (() => {
	return <Theme theme={theme}>
		<GlobalQuarklyPageStyles pageUrl={"index"} />
		<Helmet>
			<title>
				Help for you — Healthcare without the system
			</title>
			<meta name={"description"} content={"Chat with a doctor right from your phone, all day and night. No waiting room or appointment needed."} />
			<meta property={"og:title"} content={"Help for you — Healthcare without the system"} />
			<meta property={"og:description"} content={"Chat with a doctor right from your phone, all day and night. No waiting room or appointment needed."} />
			<meta property={"og:image"} content={"https://uploads.quarkly.io/6123949e957019001e284458/images/OGimage.png?v=2021-09-21T16:25:40.647Z"} />
			<link rel={"shortcut icon"} href={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} type={"image/x-icon"} />
			<link rel={"apple-touch-icon"} href={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} />
			<link rel={"apple-touch-icon"} sizes={"76x76"} href={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} />
			<link rel={"apple-touch-icon"} sizes={"152x152"} href={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} />
			<link rel={"apple-touch-startup-image"} href={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} />
			<meta name={"msapplication-TileImage"} content={"https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"} />
			<meta name={"msapplication-TileColor"} content={"#eff0a7"} />
		</Helmet>
		<Section background="linear-gradient(264.47deg,#79de73 29.39%,#c7ce67 93.49%)" padding="36px 0 36px 0" quarkly-title="Header">
			<Override slot="SectionContent" flex-direction="row" />
			<Box
				empty-border-width="1px"
				empty-border-style="solid"
				width="30%"
				sm-width="50%"
				display="flex"
				align-items="center"
				empty-min-width="64px"
				empty-min-height="64px"
				empty-border-color="LightGray"
			>
				<Image
					height="auto"
					src="https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z"
					width="100%"
					max-width="250px"
					min-height="18px"
					srcSet="https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20%3A35%3A31.470Z&quality=85&w=3200 3200w"
					sizes="(max-width: 460px) 100vw,(max-width: 767px) 100vw,(max-width: 992px) 100vw,100vw"
				/>
			</Box>
			<Box
				empty-min-height="64px"
				empty-border-width="1px"
				width="70%"
				sm-width="50%"
				align-items="center"
				empty-min-width="64px"
				empty-border-style="solid"
				empty-border-color="LightGray"
				display="flex"
			/>
			<Link
				href="/index"
				color="#ffffb6"
				text-align="center"
				padding="30px 0px 0px 0px"
				width="500px"
				font="25px sans-serif"
			>
				<Strong
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
					transition="all 0s --transitionTimingFunction-easeIn 0s"
				>
					<Em
						overflow-wrap="normal"
						word-break="normal"
						white-space="normal"
						text-indent="0"
						text-overflow="clip"
						hyphens="manual"
						user-select="auto"
						pointer-events="auto"
					>
						Home
					</Em>
				</Strong>
			</Link>
			<Link
				href="/recommendations"
				color="#ffffb6"
				text-align="center"
				padding="20px 0px 0px 0px"
				width="500px"
				font="25px sans-serif"
			>
				<Strong
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					<Em
						overflow-wrap="normal"
						word-break="normal"
						white-space="normal"
						text-indent="0"
						text-overflow="clip"
						hyphens="manual"
						user-select="auto"
						pointer-events="auto"
					>
						Stock Recommendation
					</Em>
				</Strong>
			</Link>
			<Link
				href="/filters"
				color="#ffffb6"
				text-align="center"
				padding="20px 0px 0px 0px"
				width="300px"
				font="25px sans-serif"
			>
				<Strong
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					<Em
						overflow-wrap="normal"
						word-break="normal"
						white-space="normal"
						text-indent="0"
						text-overflow="clip"
						hyphens="manual"
						user-select="auto"
						pointer-events="auto"
					>
						Stock Filtering
					</Em>
				</Strong>
			</Link>
		</Section>
		<Section background="linear-gradient(264.47deg,#79de73 29.39%,#c7ce67 93.49%)" padding="36px 0 80px 0" quarkly-title="HeroBlock" md-padding="36px 0 60px 0">
			<Override
				slot="SectionContent"
				flex-direction="row"
				position="relative"
				z-index="9"
				md-flex-wrap="wrap"
				md-z-index="7"
			/>
			<Box
				empty-min-width="64px"
				empty-min-height="64px"
				empty-border-width="1px"
				empty-border-style="solid"
				empty-border-color="LightGray"
				flex-direction="column"
				display="flex"
				align-items="flex-start"
				lg-padding="0px 90px 0px 0px"
				md-width="100%"
				justify-content="center"
				width="70%"
				padding="0px 180px 0px 0px"
				md-padding="0px 0px 0px 0px"
			>
				<Text
					lg-text-align="left"
					lg-font="normal 700 40px/1.2 &quot;Inter&quot;, sans-serif"
					md-font="normal 700 28px/1.2 &quot;Inter&quot;, sans-serif"
					margin="0px 0px 16px 0px"
					font="--headline1"
					color="--white"
					sm-font="normal 500 30px/1.2 &quot;Inter&quot;, sans-serif"
				>
					Don't put all your eggs
					<br />
					in one basket
				</Text>
			</Box>
			<Image
				src="https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18:02:21.299Z"
				display="block"
				max-width="400px"
				srcSet="https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/duck.jpeg?v=2024-11-05T18%3A02%3A21.299Z&quality=85&w=3200 3200w"
				sizes="(max-width: 460px) 100vw,(max-width: 767px) 100vw,(max-width: 992px) 100vw,100vw"
			/>
		</Section>
		<Components.Boxes />
		<Section>
			<Image src="https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20:28:25.899Z" display="block" srcSet="https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20%3A28%3A25.899Z&quality=85&w=3200 3200w" sizes="(max-width: 460px) 100vw,(max-width: 767px) 100vw,(max-width: 992px) 100vw,100vw" />
		</Section>
		<Section sm-padding="80px 0 24px 0" md-padding="50px 0 24px 0">
			<Override slot="SectionContent" flex-direction="row" md-flex-wrap="wrap" />
			<Box
				width="50%"
				flex-direction="column"
				md-width="100%"
				empty-min-width="64px"
				empty-border-style="solid"
				empty-border-color="LightGray"
				padding="16px 16px 16px 16px"
				display="flex"
				align-items="flex-start"
				justify-content="space-between"
				empty-min-height="64px"
				empty-border-width="1px"
			>
				<Image
					position="static"
					lg-left="0px"
					md-width="100%"
					border-radius="10px"
					lg-max-height="366px"
					src="https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20:42:13.927Z"
					left="-140px"
					max-width="100%"
					object-fit="cover"
					srcSet="https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/topstocks.png?v=2024-11-08T20%3A42%3A13.927Z&quality=85&w=3200 3200w"
					sizes="(max-width: 460px) 100vw,(max-width: 767px) 100vw,(max-width: 992px) 100vw,100vw"
				/>
			</Box>
			<Box
				justify-content="space-between"
				empty-min-height="64px"
				empty-border-style="solid"
				width="50%"
				padding="16px 16px 16px 16px"
				display="flex"
				md-width="100%"
				empty-min-width="64px"
				empty-border-width="1px"
				empty-border-color="LightGray"
				flex-direction="column"
				align-items="flex-start"
			>
				<Text
					width="85%"
					lg-width="100%"
					lg-font="normal 700 34px/1.2 &quot;Inter&quot;, sans-serif"
					md-font="normal 700 24px/1.2 &quot;Inter&quot;, sans-serif"
					margin="0px 0px 16px 20px"
					font="--headline2"
					color="--indigo"
					sm-font="normal 800 30px/1.2 &quot;Inter&quot;, sans-serif"
					text-align="center"
				>
					Use our Stock Filters
				</Text>
				<Text
					font="--base"
					opacity=".7"
					lg-font="normal 400 16px/1.5 &quot;Inter&quot;, sans-serif"
					md-font="normal 400 14px/1.5 &quot;Inter&quot;, sans-serif"
					margin="0px 0px 25px 0px"
					color="--dark"
					text-align="center"
				>
					Our free to use Stock Filters allows you to find excellent stock options based upon various parameters you can filter from!
				</Text>
				<Link
					href="/filters"
					sm-padding="15px 20px 15px 20px"
					hover-background="rgba(5, 165, 255, 0)"
					border-width="1px"
					border-style="solid"
					font="--lead"
					sm-margin="0px 22px 0px 0px"
					border-color="rgba(255, 255, 255, 0.3)"
					md-width="100%"
					md-font="normal 500 16px/1.6 &quot;Inter&quot;, sans-serif"
					text-decoration-line="initial"
					color="--white"
					margin="0px 44px 0px 220px"
					hover-color="--primary"
					hover-border-color="--color-primary"
					md-text-align="center"
					background="--color-primary"
					padding="15px 30px 15px 30px"
					border-radius="10px"
					sm-font="normal 500 18px/1.6 &quot;Inter&quot;, sans-serif"
					transition="background-color 0.3s --transitionTimingFunction-easeInOut 0s"
					text-align="center"
				>
					Try it out!
				</Link>
			</Box>
		</Section>
		<Components.BottomOfSite />
		<Components.Divider />
		<Link
			font={"--capture"}
			font-size={"10px"}
			position={"fixed"}
			bottom={"12px"}
			right={"12px"}
			z-index={"4"}
			border-radius={"4px"}
			padding={"5px 12px 4px"}
			background-color={"--dark"}
			opacity={"0.6"}
			hover-opacity={"1"}
			color={"--light"}
			cursor={"pointer"}
			transition={"--opacityOut"}
			quarkly-title={"Badge"}
			text-decoration-line={"initial"}
			href={"https://quarkly.io/"}
			target={"_blank"}
		>
			Made on Quarkly
		</Link>
		<RawHtml>
			<style place={"endOfHead"} rawKey={"6123949e957019001e284456"}>
				{":root {\n  box-sizing: border-box;\n}\n\n* {\n  box-sizing: inherit;\n}"}
			</style>
		</RawHtml>
	</Theme>;
});