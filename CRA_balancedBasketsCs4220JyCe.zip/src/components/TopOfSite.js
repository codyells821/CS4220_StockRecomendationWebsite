import React from "react";
import { useOverrides, Override } from "@quarkly/components";
import { Image, Box, Link, Em, Strong, Section } from "@quarkly/widgets";
const defaultProps = {
	"background": "linear-gradient(264.47deg,#79de73 29.39%,#c7ce67 93.49%)",
	"padding": "36px 0 36px 0",
	"quarkly-title": "Header"
};
const overrides = {
	"box": {
		"kind": "Box",
		"props": {
			"empty-border-width": "1px",
			"empty-border-style": "solid",
			"width": "30%",
			"sm-width": "50%",
			"display": "flex",
			"align-items": "center",
			"empty-min-width": "64px",
			"empty-min-height": "64px",
			"empty-border-color": "LightGray"
		}
	},
	"image": {
		"kind": "Image",
		"props": {
			"height": "auto",
			"src": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z",
			"width": "100%",
			"max-width": "250px",
			"min-height": "18px"
		}
	},
	"box1": {
		"kind": "Box",
		"props": {
			"empty-min-height": "64px",
			"empty-border-width": "1px",
			"width": "70%",
			"sm-width": "50%",
			"align-items": "center",
			"empty-min-width": "64px",
			"empty-border-style": "solid",
			"empty-border-color": "LightGray",
			"display": "flex"
		}
	},
	"link": {
		"kind": "Link",
		"props": {
			"href": "/index",
			"color": "#ffffb6",
			"text-align": "center",
			"padding": "30px 0px 0px 0px",
			"width": "500px",
			"font": "25px sans-serif",
			"children": <Strong
				overflow-wrap="normal"
				word-break="normal"
				white-space="normal"
				text-indent="0"
				text-overflow="clip"
				hyphens="manual"
				user-select="auto"
				pointer-events="auto"
			>
				<Em
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					Home
				</Em>
			</Strong>
		}
	},
	"link1": {
		"kind": "Link",
		"props": {
			"href": "/recommendations",
			"color": "#ffffb6",
			"text-align": "center",
			"padding": "20px 0px 0px 0px",
			"width": "500px",
			"font": "25px sans-serif",
			"children": <Strong
				overflow-wrap="normal"
				word-break="normal"
				white-space="normal"
				text-indent="0"
				text-overflow="clip"
				hyphens="manual"
				user-select="auto"
				pointer-events="auto"
			>
				<Em
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					Stock Recommendation
				</Em>
			</Strong>
		}
	},
	"link2": {
		"kind": "Link",
		"props": {
			"href": "/filters",
			"color": "#ffffb6",
			"text-align": "center",
			"padding": "20px 0px 0px 0px",
			"width": "300px",
			"font": "25px sans-serif",
			"children": <Strong
				overflow-wrap="normal"
				word-break="normal"
				white-space="normal"
				text-indent="0"
				text-overflow="clip"
				hyphens="manual"
				user-select="auto"
				pointer-events="auto"
			>
				<Em
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					Stock Filtering
				</Em>
			</Strong>
		}
	}
};

const TopOfSite = props => {
	const {
		override,
		children,
		rest
	} = useOverrides(props, overrides, defaultProps);
	return <Section {...rest}>
		<Override slot="SectionContent" flex-direction="row" />
		<Box {...override("box")}>
			<Image {...override("image")} />
		</Box>
		<Box {...override("box1")} />
		<Link {...override("link")} />
		<Link {...override("link1")} />
		<Link {...override("link2")} />
		{children}
	</Section>;
};

Object.assign(TopOfSite, { ...Section,
	defaultProps,
	overrides
});
export default TopOfSite;