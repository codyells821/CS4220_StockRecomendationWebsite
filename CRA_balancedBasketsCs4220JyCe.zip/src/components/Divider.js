import React from "react";
import { useOverrides } from "@quarkly/components";
import { Image, Section } from "@quarkly/widgets";
const defaultProps = {};
const overrides = {
	"image": {
		"kind": "Image",
		"props": {
			"src": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/Untitled.png?v=2024-11-08T20:28:25.899Z",
			"display": "block"
		}
	}
};

const Divider = props => {
	const {
		override,
		children,
		rest
	} = useOverrides(props, overrides, defaultProps);
	return <Section {...rest}>
		<Image {...override("image")} />
		{children}
	</Section>;
};

Object.assign(Divider, { ...Section,
	defaultProps,
	overrides
});
export default Divider;