import React from "react";
import { useOverrides, Override } from "@quarkly/components";
import { Image, Text, Section } from "@quarkly/widgets";
const defaultProps = {
	"background": "#79de73 linear-gradient(0deg,#c7ce67 0%,#79de73 58.6%)",
	"padding": "100px 0 100px 0",
	"md-padding": "40px 0 40px 0"
};
const overrides = {
	"image": {
		"kind": "Image",
		"props": {
			"height": "auto",
			"src": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/GT.png?v=2024-11-08T20:09:19.546Z",
			"width": "100%",
			"max-width": "171px"
		}
	},
	"text": {
		"kind": "Text",
		"props": {
			"margin": "0px 0px 0px 20px",
			"padding": "30px 0px 0px 0px",
			"children": <>
				Website Created by Justin Yang and Cody Ells
				<br />
				<br />
				CS 4220 - Fall 2024
			</>
		}
	},
	"image1": {
		"kind": "Image",
		"props": {
			"height": "auto",
			"src": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/balancedbasketlogo.png?v=2024-11-08T20:35:31.470Z",
			"width": "100%",
			"max-width": "171px",
			"padding": "0px 0px 0px 20px"
		}
	}
};

const BottomOfSite = props => {
	const {
		override,
		children,
		rest
	} = useOverrides(props, overrides, defaultProps);
	return <Section {...rest}>
		<Override
			slot="SectionContent"
			flex-direction="row"
			md-flex-wrap="wrap"
			color="#ffed4e"
			font="20px sans-serif"
			position="relative"
			text-align="center"
			top="px"
			left="250px"
		/>
		<Image {...override("image")} />
		<Text {...override("text")} />
		<Image {...override("image1")} />
		{children}
	</Section>;
};

Object.assign(BottomOfSite, { ...Section,
	defaultProps,
	overrides
});
export default BottomOfSite;