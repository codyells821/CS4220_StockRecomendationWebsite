import React from "react";
import { useOverrides, Override } from "@quarkly/components";
import { Image, Box, Text, Link, Section } from "@quarkly/widgets";
const defaultProps = {
	"padding": "px 0 24px 0",
	"sm-padding": "80px 0 24px 0",
	"md-padding": "50px 0 24px 0",
	"margin": "20px 0 0 0"
};
const overrides = {
	"box": {
		"kind": "Box",
		"props": {
			"width": "50%",
			"flex-direction": "column",
			"md-width": "100%",
			"empty-min-width": "64px",
			"empty-border-style": "solid",
			"empty-border-color": "LightGray",
			"padding": "16px 16px 16px 16px",
			"display": "flex",
			"align-items": "flex-start",
			"justify-content": "space-between",
			"empty-min-height": "64px",
			"empty-border-width": "1px"
		}
	},
	"image": {
		"kind": "Image",
		"props": {
			"position": "static",
			"lg-left": "0px",
			"md-width": "100%",
			"border-radius": "10px",
			"lg-max-height": "366px",
			"src": "https://uploads.quarkly.io/67113ea841a0cf0024a4d2e4/images/chart.png?v=2024-11-08T20:44:15.366Z",
			"left": "-140px",
			"max-width": "100%",
			"object-fit": "cover",
			"width": "500px"
		}
	},
	"box1": {
		"kind": "Box",
		"props": {
			"justify-content": "space-between",
			"empty-min-height": "64px",
			"empty-border-style": "solid",
			"width": "50%",
			"padding": "16px 16px 16px 16px",
			"display": "flex",
			"md-width": "100%",
			"empty-min-width": "64px",
			"empty-border-width": "1px",
			"empty-border-color": "LightGray",
			"flex-direction": "column",
			"align-items": "flex-start"
		}
	},
	"text": {
		"kind": "Text",
		"props": {
			"width": "85%",
			"lg-width": "100%",
			"lg-font": "normal 700 34px/1.2 \"Inter\", sans-serif",
			"md-font": "normal 700 24px/1.2 \"Inter\", sans-serif",
			"margin": "0px 0px 16px 20px",
			"font": "--headline2",
			"color": "--indigo",
			"sm-font": "normal 800 30px/1.2 \"Inter\", sans-serif",
			"text-align": "center",
			"children": "Get Personal Stock Recommendations"
		}
	},
	"text1": {
		"kind": "Text",
		"props": {
			"font": "--base",
			"opacity": ".7",
			"lg-font": "normal 400 16px/1.5 \"Inter\", sans-serif",
			"md-font": "normal 400 14px/1.5 \"Inter\", sans-serif",
			"margin": "0px 0px 25px 0px",
			"color": "--dark",
			"text-align": "center",
			"children": "Use our free tool where you can input your own Stock Holdings and then you can be recommended areas which you can help you to balance your assets!"
		}
	},
	"link": {
		"kind": "Link",
		"props": {
			"href": "/recommendations",
			"sm-padding": "15px 20px 15px 20px",
			"hover-background": "rgba(5, 165, 255, 0)",
			"border-width": "1px",
			"border-style": "solid",
			"font": "--lead",
			"sm-margin": "0px 22px 0px 0px",
			"border-color": "rgba(255, 255, 255, 0.3)",
			"md-width": "100%",
			"md-font": "normal 500 16px/1.6 \"Inter\", sans-serif",
			"text-decoration-line": "initial",
			"color": "--white",
			"margin": "0px 44px 0px 220px",
			"hover-color": "--primary",
			"hover-border-color": "--color-primary",
			"md-text-align": "center",
			"background": "--color-primary",
			"padding": "15px 30px 15px 30px",
			"border-radius": "10px",
			"sm-font": "normal 500 18px/1.6 \"Inter\", sans-serif",
			"transition": "background-color 0.3s --transitionTimingFunction-easeInOut 0s",
			"children": "Try it out!"
		}
	}
};

const Boxes = props => {
	const {
		override,
		children,
		rest
	} = useOverrides(props, overrides, defaultProps);
	return <Section {...rest}>
		<Override slot="SectionContent" flex-direction="row" md-flex-wrap="wrap" />
		<Box {...override("box")}>
			<Image {...override("image")} />
		</Box>
		<Box {...override("box1")}>
			<Text {...override("text")} />
			<Text {...override("text1")} />
			<Link {...override("link")} />
		</Box>
		{children}
	</Section>;
};

Object.assign(Boxes, { ...Section,
	defaultProps,
	overrides
});
export default Boxes;